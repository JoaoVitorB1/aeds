public class exercicio1 {
    static int multiplica(int a,int b){
        int resultado=0;
        if(b>0){
            resultado = a+multiplica(a, b-1);
        }
        return resultado;
    }
    public static void main(String[] args){
        int a = 2,b=4;
        int resultado = multiplica(a,b);
        System.out.println(resultado);
    }
}
