public class exercicioif1 {
    public static void main (String[] args){
        int a=0,b=0,c=0;
        a = MyIO.readInt();
        b = MyIO.readInt();
        c = MyIO.readInt();
        int menor = a;
        int maior = 0;

        if(menor>b){
            menor=b;
        }if(menor>c){
            menor = c;
        }
        if(maior<a){
            maior=a;
        }if(maior<b){
            maior=b;
        }if(maior<c){
            maior=c;
        }
        System.out.println(maior);
        System.out.println(menor);
    }
}
