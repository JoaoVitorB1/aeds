public class exercicioif2 {
    public static void main(String[] args){
        int[] a; 
        a = new int[10];
        for(int i = 0;i<10;i++){
            a[i]=MyIO.readInt();
        }
        int maior=0;
        for(int i=0;i<10;i++){
            if(a[i]>maior){
                maior=a[i];
            }
        }
        System.out.println(maior);
        
    }
}
