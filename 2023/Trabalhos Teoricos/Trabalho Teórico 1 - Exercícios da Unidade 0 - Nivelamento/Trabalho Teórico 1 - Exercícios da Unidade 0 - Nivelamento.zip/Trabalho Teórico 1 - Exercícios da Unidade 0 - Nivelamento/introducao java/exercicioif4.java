public class exercicioif4 {
    public static void main(String[] args){
        int m=0,v=0;
        m=MyIO.readInt();
        v=MyIO.readInt();
        if(m>v){
            System.out.println("Mandante");
        }else if(m<v){
            System.out.println("Visitante");
        }else{
            System.out.println("Empate");
        }
    }
}
