class exercicioif {
    public static void main (String[] args){
      int a=0,b=0,c=0;
      a = MyIO.readInt();
      b = MyIO.readInt();
      c = MyIO.readInt();

      if(a==b&&b==c){
        System.out.println("EQUILATERO");
      }if(a==b&&a!=c&&b!=c){
        System.out.println("ISOSCELES");
      }if((a<b&&a<c)&&(b<c)){
        System.out.println("ESCALENO");
      }
    }
  }