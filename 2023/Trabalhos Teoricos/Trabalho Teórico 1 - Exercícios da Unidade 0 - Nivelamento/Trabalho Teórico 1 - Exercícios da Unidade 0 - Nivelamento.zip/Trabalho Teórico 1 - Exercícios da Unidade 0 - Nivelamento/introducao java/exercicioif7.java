public class exercicioif7 {
    public static void main(String[] args){
        int[] a; 
        a = new int[10];
        for(int i=0;i<10;i++){
            a[i]=MyIO.readInt();
        }
        int maior=0;
        int menor=a[0];
        for(int i=0;i<10;i++){
            if(menor>a[i]){
                menor=a[i];
            }
            if(maior<a[i]){
                maior=a[i];
            }
        }
        System.out.println(maior);
        System.out.println(menor);
    }
}
