public class exercicioif3 {
    public static void main(String[] args){
        int a =0,b=0;
        a=MyIO.readInt();
        b=MyIO.readInt();
        int resultado = 0;
        if(a>45||b>45){
            resultado=a+b;
            System.out.println(resultado);
        }else if(a>20&&b>20){
            if(a>b){
                resultado=a-b;
                System.out.println(resultado);
            }else{
                resultado=b-a;
                System.out.println(resultado);
            }
        }else if((a<10&&b!=0)||(b<10&&a!=0)){
            resultado=a/b;
            System.out.println(resultado);
        }else{
            System.out.println("Joao Vitor");
        }
        System.out.println(resultado);
    }
}
