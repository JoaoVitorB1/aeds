public class exerciciowhile2 {
    public static void main(String[] args){

        int a=0,contador=0;
        a=MyIO.readInt();
        int i=1;
        while(contador<a){
            if((i%2)!=0){
                System.out.println(i);
                contador++;
            }
            i++;
        }
    }    
}
