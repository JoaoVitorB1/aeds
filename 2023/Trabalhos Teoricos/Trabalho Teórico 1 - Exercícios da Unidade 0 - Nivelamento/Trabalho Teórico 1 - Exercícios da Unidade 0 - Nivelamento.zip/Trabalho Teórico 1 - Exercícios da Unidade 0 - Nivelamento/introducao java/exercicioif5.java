public class exercicioif5 {
    public static void main(String[] args){
        double s=0.00,p=0.00;
        s=MyIO.readDouble();
        p=MyIO.readDouble();
        if((s*0.4)>p){
            System.out.println("SIM");
        }else{
            System.out.println("NAO");
        }
    }
}
