public class exerciciowhile {
    public static void main(String[] args){
        
        double nota=0.0,media=0.0,total=0.0;
        int i=0;
        while(i<5){
            nota=MyIO.readDouble();
            total+=nota;
            i++;
        }
        media=total/5;
        System.out.println(media);
        
    }
}
