#include <stdio.h>
#include <stdbool.h>

bool verficar(int x[10], int y) {
//falta fazer essa parte
  bool resp = false;
  int dir = 10 - 1, esq = 0, meio;
  while (esq <= dir) {
    meio = (esq + dir) / 2;
    if (y == x[meio]) {
      resp = true;
      esq = 10;
    } else if (y > x[meio]) {
      esq = meio + 1;
    } else {
      dir = meio - 1;
    }
  }

  return resp;
}
int main(void) {
  int i[]={10,4,6,8,2,12,14,16,18,20};
  verficar(i);
  return 0;
}