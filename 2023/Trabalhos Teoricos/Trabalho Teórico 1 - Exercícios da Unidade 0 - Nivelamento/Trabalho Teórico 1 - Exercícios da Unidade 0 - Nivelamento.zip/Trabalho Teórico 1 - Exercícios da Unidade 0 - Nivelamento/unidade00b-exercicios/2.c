#include <stdbool.h>
#include <stdio.h>

bool verficar(int x[10], int y) {

  bool resp = false;
  int dir = 10 - 1, esq = 0, meio;
  while (esq <= dir) {
    meio = (esq + dir) / 2;
    if (y == x[meio]) {
      resp = true;
      esq = 10;
    } else if (y > x[meio]) {
      esq = meio + 1;
    } else {
      dir = meio - 1;
    }
  }

  return resp;
}
int main(void) {
  int i[] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
  int num = 0;
  scanf("%d", &num);
  if (verficar(i, num) == true) {
    printf("SIM");
  } else {
    printf("NAO");
  }
  return 0;
}