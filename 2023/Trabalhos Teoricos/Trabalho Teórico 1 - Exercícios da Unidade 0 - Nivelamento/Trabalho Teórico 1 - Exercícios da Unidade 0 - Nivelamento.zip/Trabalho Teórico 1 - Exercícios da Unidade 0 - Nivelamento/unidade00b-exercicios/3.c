#include <stdio.h>
#include <stdbool.h>

void verficar(int x[10]){
  int maior=0,menor=x[0];
  for(int i=0;i<10;i++){
    if(x[i]>=maior){
      maior=x[i];
    }
    if(x[i]<=menor){
      menor=x[i];
    }
  }
  printf("MAIOR: %d\nMENOR: %d", maior,menor);
}
int main(void) {
  int i[]={10,4,6,8,2,12,14,16,18,20};
  verficar(i);
  return 0;
}