#include <stdbool.h>
#include <stdio.h>

bool verficar(int x[10], int y) {

  bool resp = false;
  for(int i=0;i<10;i++){
    if(x[i]==y){
      resp = true;
      break;
    }
  }

  return resp;
}
int main(void) {
  int i[] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
  int num = 0;
  scanf("%d", &num);
  if (verficar(i, num) == true) {
    printf("SIM");
  } else {
    printf("NAO");
  }
  return 0;
}